/*
 * MPU9250_prototypes.h
 *
 *  Created on: Jul 28, 2017
 *      Author: JJH
 */

#ifndef MPU9250_PROTOTYPES_H_
#define MPU9250_PROTOTYPES_H_

void  MPU9250_if_init( void );

unsigned MPU9250_readID();

unsigned MPU9250_readGyroX();
unsigned MPU9250_readGyroY();
unsigned MPU9250_readGyroZ();

unsigned MPU9250_readAccelX();
unsigned MPU9250_readAccelY();
unsigned MPU9250_readAccelZ();


#endif /* MPU9250_PROTOTYPES_H_ */
