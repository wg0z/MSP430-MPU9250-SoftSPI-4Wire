/*
 * MPU9250_SPI_config.h
 *
 *  Created on: Jul 28, 2017
 *      Author: JJH
 */

#ifndef MPU9250_SPI_CONFIG_H_
#define MPU9250_SPI_CONFIG_H_


#define CLK_OUTPORT  P1OUT
#define CLK_DIRPORT  P1DIR
#define CLK_BIT_NUM  0
#define CLK_BIT_MASK (1 << CLK_BIT_NUM)

#define MOSI_OUTPORT   P1OUT
#define MOSI_DIRPORT   P1DIR
#define MOSI_BIT_NUM   1
#define MOSI_BIT_MASK  (1 << MOSI_BIT_NUM)

#define MISO_INPORT   P1IN
#define MISO_DIRPORT  P1DIR
#define MISO_RENPORT  PIREN
#define MISO_BIT_NUM   2
#define MISO_BIT_MASK  (1 << MISO_BIT_NUM)

#define CS_OUTPORT   P1OUT
#define CS_DIRPORT   P1DIR
#define CS_BIT_NUM   3
#define CS_BIT_MASK  (1 << CS_BIT_NUM)

#define FSYNC_OUTPORT   P1OUT
#define FSYNC_DIRPORT   P1DIR
#define FSYNC_BIT_NUM   4
#define FSYNC_BIT_MASK  (1 << FSYNC_BIT_NUM)



#endif /* MPU9250_SPI_CONFIG_H_ */
