/*
 * MPU925_SPI_primitives.c
 *
 *  Created on: Jul 28, 2017
 *      Author: JJH
 */

#include <MSP430.h>
#include "MPU9250_named_numbers.h"
#include "MPU9250_SPI_config.h"
#include "MPU9250_prototypes.h"

#define SELECT_L    CS_OUTPORT &= ~CS_BIT_MASK  // active-LOW signal
#define DESELECT    CS_OUTPORT |= CS_BIT_MASK
#define MOSI_LO     MOSI_OUTPORT &= ~MOSI_BIT_MASK
#define MOSI_HI     MOSI_OUTPORT |= MOSI_BIT_MASK
#define SCLK_HI     CLK_OUTPORT |= CLK_BIT_MASK
#define SCLK_LO     CLK_OUTPORT &= ~CLK_BIT_MASK


unsigned Word, WordMask;

static unsigned char regRead( unsigned Reg )
{
    unsigned Count;

    // send 8 bits to define the register and READ as the action
    // the MSB is transmitted first
    WordMask = 0x80;
    Word = (Reg | REG_READ); // for read, make sure MSB of register value is SET

    SELECT_L;

    do
    {
        SCLK_LO;
        if (WordMask & Word)
          MOSI_HI;
        else
          MOSI_LO;
        SCLK_HI;
        WordMask = WordMask >> 1;
    }
    while (WordMask);

    // make sure MOSI is low
    MOSI_LO;

    // now read the MISO line 8 times to get the contents of the register
    Word = 0;
    for ( Count = 8; Count > 0; Count--)
    {
       Word = Word << 1;
       SCLK_LO;
       SCLK_HI;
       if (MISO_INPORT & MISO_BIT_MASK)
           Word |= 1;
    }

    DESELECT;

    return (unsigned char)Word;

}



void  MPU9250_if_init( void )
{

    // set three bits HI in port OUTPUT register so
    // that states for CS, MOSI, SCLK will all be HIGH as pin
    // mode is set to OUTPUT
    DESELECT;
    MOSI_HI;
    SCLK_HI;

    // now set pin mode to OUTPUT for CS, MOSI, SCL
    CS_DIRPORT   |= CS_BIT_MASK;
    MOSI_DIRPORT |= MOSI_BIT_MASK;
    CLK_DIRPORT  |= CLK_BIT_MASK;

}


unsigned MPU9250_readID( void )
{
    return (unsigned)regRead( WHO_AM_I );
}

unsigned MPU9250_readGyroX( void )
{
    return (((unsigned)regRead( GYRO_XOUT_H)) << 8) | (unsigned)regRead( GYRO_XOUT_L);
}

unsigned MPU9250_readGyroY( void )
{
    return (((unsigned)regRead( GYRO_YOUT_H)) << 8) | (unsigned)regRead( GYRO_YOUT_L);
}

unsigned MPU9250_readGyroZ( void )
{
    return (((unsigned)regRead( GYRO_ZOUT_H)) << 8) | (unsigned)regRead( GYRO_ZOUT_L);
}


unsigned MPU9250_readAccelX( void )
{
    return (((unsigned)regRead( ACCEL_XOUT_H)) << 8) | (unsigned)regRead( ACCEL_XOUT_L);
}

unsigned MPU9250_readAccelY( void )
{
    return (((unsigned)regRead( ACCEL_YOUT_H)) << 8) | (unsigned)regRead( ACCEL_YOUT_L);
}

unsigned MPU9250_readAccelZ( void )
{
    return (((unsigned)regRead( ACCEL_ZOUT_H)) << 8) | (unsigned)regRead( ACCEL_ZOUT_L);
}
