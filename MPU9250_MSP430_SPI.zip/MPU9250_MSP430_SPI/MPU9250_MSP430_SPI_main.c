//
// MPU9250_MSP430_SPI_main.c
//

#include <msp430.h>
#include "MPU9250_prototypes.h"


static unsigned Id, IdError;
static unsigned Gyro_X, Gyro_Y, Gyro_Z;
static unsigned Accel_X, Accel_Y, Accel_Z;


void main(void)
{
	WDTCTL = WDTPW | WDTHOLD;		// stop watchdog timer

    MPU9250_if_init();

    Id = MPU9250_readID();

    if ( 0x71 != Id)
        IdError = 1;

    for(;;)
    {
        Gyro_X = MPU9250_readGyroX();
        Gyro_Y = MPU9250_readGyroY();
        Gyro_Z = MPU9250_readGyroZ();

        Accel_X = MPU9250_readAccelX();
        Accel_Y = MPU9250_readAccelY();
        Accel_Z = MPU9250_readAccelZ();

    } // end for()

} // end main()
